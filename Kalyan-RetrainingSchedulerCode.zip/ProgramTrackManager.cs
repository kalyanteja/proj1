﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TrainingDay
{
    static class ProgramTrackManager
    {
        public static List<(int, string)[]> GetDaywiseTrainings(List<(int, string)> allTrainings)
        {
            var totalProgramDuration = allTrainings.Select(x => x.Item1).Aggregate((a, b) => a + b);
            var noOfDays = (int)Math.Ceiling(totalProgramDuration / (60d * 7));

            Console.WriteLine("Total program time - " + totalProgramDuration + " minutes");
            Console.WriteLine("No. of Tracks - " + noOfDays);

            List<(int, string)[]> slots = new List<(int, string)[]>();
            int totalTrainingsCount = allTrainings.Count;
            int trainingsCount = 0;
            int trainingsPerDay = (1 + totalTrainingsCount) / noOfDays;
            int index = 0;

            while (index < noOfDays)
            {
                index++;

                var daySlot = index >= noOfDays
                    ? new (int, string)[totalTrainingsCount - trainingsCount]
                    : new (int, string)[(1 + totalTrainingsCount) / noOfDays];

                slots.Add(daySlot);
                trainingsCount += trainingsPerDay;
            }

            return divideTrainingsIntoEqualParts(allTrainings, slots);
        }

        private static List<(int, string)[]> divideTrainingsIntoEqualParts(
            List<(int, string)> allTrainings,
            List<(int, string)[]> slots)
        {
            var maxTrainingsSlotSize = slots.First().Length;
            allTrainings = allTrainings.OrderBy(ar => ar.Item1).ToList();

            var daywiseTrainingsCount = new List<int>(new int[slots.Count]);
            var daywiseTotalDuration = new List<int>(new int[slots.Count]);
            
            int index = allTrainings.Count - 1;

            while (daywiseTrainingsCount.All(pos => pos < maxTrainingsSlotSize))
            {
                var dayFlag = false;
                int dayPosition;
                for (dayPosition = 0; dayPosition < slots.Count - 1; dayPosition++)
                {
                    if (daywiseTotalDuration[dayPosition] < daywiseTotalDuration[dayPosition + 1] && !dayFlag)
                    {
                        slots[dayPosition][daywiseTrainingsCount[dayPosition]] = allTrainings[index];
                        daywiseTrainingsCount[dayPosition] = daywiseTrainingsCount[dayPosition] + 1;
                        daywiseTotalDuration[dayPosition] = daywiseTotalDuration[dayPosition] + allTrainings[index].Item1;
                        dayFlag = true;
                    }
                }

                if (!dayFlag)
                {
                    slots[dayPosition][daywiseTrainingsCount[dayPosition]] = allTrainings[index];
                    daywiseTrainingsCount[dayPosition] = daywiseTrainingsCount[dayPosition] + 1;
                    daywiseTotalDuration[dayPosition] = daywiseTotalDuration[dayPosition] + allTrainings[index].Item1;
                }

                index--;
            }

            while (index >= 0)
            {
                var dayFlag = false;
                int dayPosition;
                for (dayPosition = 0; dayPosition < slots.Count - 1; dayPosition++)
                {
                    if (daywiseTrainingsCount[dayPosition] < maxTrainingsSlotSize && !dayFlag)
                    {
                        slots[dayPosition][daywiseTrainingsCount[dayPosition]] = allTrainings[index];
                        daywiseTrainingsCount[dayPosition] = daywiseTrainingsCount[dayPosition] + 1;
                        dayFlag = true;
                    }
                }

                if (!dayFlag)
                {
                    slots[dayPosition][daywiseTrainingsCount[dayPosition]] = allTrainings[index];
                    daywiseTrainingsCount[dayPosition] = daywiseTrainingsCount[dayPosition] + 1;
                }

                index--;
            }

            return slots;
        }
    }
}