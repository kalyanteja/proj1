Retraining Scheduler
--------------------

## Input data
- The program accepts the training input in a specific format as in the file TrainingItenary.txt
- Here's the format:
	60**NAMEOFTRAINING --> {training duration}**{training name}
- Make sure you change the path of your file 
	Start_RetrainingScheduler.cs class -> change variable 'INPUT_FILE' path

## Assumptions
1. Only max of 7 hours trainings per day allowed
2. If there are trainings spanning for larger duration say for 5 hours, we split them over lunch Break and continue after
3. Based on the total duration of input trainings we span the Tracks into multiple days of equal hours of trainigs (could go for 3 tracks)
4. Sharing session only start after 4PM even if we finish trainings before that time (and do not have an end time - not given in the requirements doc)


## Code
1. For coding conventions only, used double representation of hours and minutes i.e. 17.25 is 5:15 PM
2. Written tests using NUnit
3. Main entry to the code is Start_RetrainingScheduler.cs(Program) -> Main method