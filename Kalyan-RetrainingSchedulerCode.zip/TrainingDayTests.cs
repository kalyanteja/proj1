﻿using NUnit.Framework;
using System.Collections.Generic;

namespace TrainingDay
{
    [TestFixture]
    public class TrainingDayTests
    {
        public static List<List<(int, string)>> programSchedules = new List<List<(int, string)>>{
            new List<(int, string)>
            {
                (60, "Organising Parents for Academy Improvements"),
                (45, "Teaching Innovations in the Pipeline"),
                (30, "Teacher Computer Hacks"),
                (150, "Making Your Academy Beautiful"),
                (45, "Academy Tech Field Repair"),
                (5 , "Sync Hard"),
                (5 , "Unusual Recruiting"),
                (180, "Parent Teacher Conferences"),
                (45, "Managing Your Dire Allowance"),
                (30, "Customer Care"),
                (30, "AIMs – 'Managing Up'"),
                (45, "Dealing with Problem Teachers"),
                (90, "Hiring the Right Cook"),
                (60, "Government Policy Changes and Bridge")
            },
            new List<(int, string)>
            {
                (60, "Organising Parents for Academy Improvements"),
                (45, "Teaching Innovations in the Pipeline"),
                (30, "Teacher Computer Hacks"),
                (120, "Making Your Academy Beautiful"),
                (45, "Academy Tech Field Repair"),
                (5 , "Sync Hard"),
                (5 , "Unusual Recruiting")
            },
            new List<(int, string)>
            {
                (60, "Organising Parents for Academy Improvements"),
                (170, "Teaching Innovations in the Pipeline"),
                (40, "Teacher Computer Hacks"),
                (50, "Making Your Academy Beautiful"),
                (5 , "Unusual Recruiting")
            }
        };

        [TestCase(0, true)]
        [TestCase(1, true)]
        [TestCase(2, false)]
        public void FitTrainingsBeforeLunchTest(int programNo, bool canScheduleTrainingsBeforeLunch)
        {
            // get all possible trainings from 9AM - 12Noon (180 minutes)
            var preLunchTrainings = Program.GetAllPotentialTrainingsPreLunch(180, programSchedules[programNo]);

            Assert.AreEqual(preLunchTrainings.Count > 0, canScheduleTrainingsBeforeLunch);
        }

        //sched#, noOfTracks
        [TestCase(1, 1)] 
        [TestCase(0, 2)]
        public void GetCorrectTrackDaysForGivenScheduleTest(int programNo, int expectedTracks)
        {
            var schedule = programSchedules[programNo];
            var dayTrainings = ProgramTrackManager.GetDaywiseTrainings(schedule);

            Assert.AreEqual(dayTrainings.Count, expectedTracks);
        }

        [TestCase(2, true)]
        [TestCase(3, false)]
        public void GetTracksForAProgramTest(int expectedTracks, bool wrongDays)
        {
            var programSchedule = new List<(int, string)>
            {
                (60, "Organising Parents for Academy Improvements"),
                (45, "Teaching Innovations in the Pipeline"),
                (30, "Teacher Computer Hacks"),
                (150, "Making Your Academy Beautiful"),
                (45, "Academy Tech Field Repair"),
                (5 , "Sync Hard"),
                (5 , "Unusual Recruiting"),
                (180, "Parent Teacher Conferences"),
                (45, "Managing Your Dire Allowance"),
                (30, "Customer Care"),
                (30, "AIMs – 'Managing Up'"),
                (45, "Dealing with Problem Teachers"),
                (90, "Hiring the Right Cook"),
                (60, "Government Policy Changes and Bridge")
            };

            var dayTrainings = ProgramTrackManager.GetDaywiseTrainings(programSchedule);

            Assert.AreEqual(dayTrainings.Count == expectedTracks, wrongDays);
        }

        [TestCase(120, 11.25)]
        [TestCase(31, 11.5)]
        public void IsLunchOverRunTest(int duration, double startTime)
        {
            var isOverRun = DayTimeUtilities.IsLunchOverRun(duration, startTime);
            Assert.AreEqual(true, isOverRun);
        }

        [TestCase(120, 9)]
        [TestCase(30, 10.25)]
        public void IsWithInLunchTimeTest(int duration, double startTime)
        {
            var isOverRun = DayTimeUtilities.IsLunchOverRun(duration, startTime);
            Assert.AreEqual(false, isOverRun);
        }

        [TestCase(11.5, 30)]
        [TestCase(12.5, -30)]
        public void GetTimeRemainingForLunchTest(double currTime, double estimate)
        {
            var timeForLunch = DayTimeUtilities.GetTimeRemainingForLunch(currTime);
            Assert.AreEqual(estimate, timeForLunch);
        }
    }
}