﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TrainingDay
{
    static class DayTimeUtilities
    {
        public const int LunchStartTime = 12;

        // Math representation to Time (ex. 13.75 to 1:45PM)
        public static string ConvertToTime(double time)
        {
            var intTime = (int)time;
            string dayTime = time.ToString().Contains('.')
                ? string.Format((intTime >= 13 ? intTime - LunchStartTime : intTime) + ":" + GetDecimalAndConvertToTime(time))
                : string.Format((intTime >= 13 ? intTime - LunchStartTime : intTime) + ":00");

            if (time >= LunchStartTime)
            {
                dayTime = string.Format(dayTime + "PM");
            }
            else
            {
                dayTime = string.Format(dayTime + "AM");
            }

            return dayTime;
        }

        public static bool IsLunchOverRun(int trainingDuration, double startTime)
        {
            double duration = trainingDuration / 60d;
            return startTime + duration > LunchStartTime;
        }

        public static double LunchOverRunBy(int trainingDuration, double startTime)
        {
            double duration = trainingDuration / 60d;
            return (startTime + duration - LunchStartTime)* 60d;
        }


        public static double GetTimeRemainingForLunch(double currentTime)
        {
            return (LunchStartTime - currentTime) * 60d;
        }

        public static int GetDecimalAndConvertToTime(double value)
        {
            var first2DecimalPlaces = (int)(((decimal)value % 1) * 100);
            return (int)Math.Ceiling(first2DecimalPlaces * 3 / 5d);  // convert mathematical decimals to minutes
        }
    }        
}