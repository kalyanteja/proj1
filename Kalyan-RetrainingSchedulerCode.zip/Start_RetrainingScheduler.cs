﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace TrainingDay
{
    class Program
    {
        public const int LunchDuration = 60;
        
        public const int TrackStartTime = 9;
        public const double TrackEndTime = 17.5;
        private static List<List<(int, string)>> possiblePreLunchTrainingsForADay;

        /*
        * YOUR INPUT GOES HERE
        * Make sure any new programs you enter follow the similar format
        */
        private static readonly string INPUT_FILE = @"C:\Users\kalyant\source\repos\TrainingDay\TrainingItenary.txt";

        static void Main(string[] args)
        {
            // Here's the overall program list
            // (duration, training-program)
            var programSchedule = new List<(int, string)>();

            if (File.Exists(INPUT_FILE))
            {
                // Read a text file line by line.  
                string[] trainings = File.ReadAllLines(INPUT_FILE);

                foreach (string line in trainings)
                {
                    var trainingData = line.Trim().Split("**");
                    var trainingDuration = int.Parse(trainingData[0].Replace("lightning", "5"));
                    var trainingName = trainingData[1];
                    programSchedule.Add((trainingDuration, trainingName));
                }

                //remove duplicates
                programSchedule = programSchedule.Distinct().ToList();

                // split total program schedule into 7 hour sessions (per day)
                var daywiseTrainingsSet = ProgramTrackManager.GetDaywiseTrainings(programSchedule);

                var trackNumber = 1;
                daywiseTrainingsSet.ForEach(d => SetTrackCalendar(d.ToList(), trackNumber++));
            }
            else
            {
                Console.WriteLine("****Please check your input file, for more refer to ReadMe doc");
            }
        }

        public static List<List<(int, string)>> GetAllPotentialTrainingsPreLunch(double duration, List<(int, string)> trainings)
        {
            possiblePreLunchTrainingsForADay = new List<List<(int, string)>>();
            GetPreLunchTrainings(duration, 0, new List<(int, string)>(), new List<(int, string)>(trainings), 0);
            return possiblePreLunchTrainingsForADay;
        }

        private static void GetPreLunchTrainings(
            double duration,
            double totalDuration,
            List<(int, string)> trainingsIncluded,
            List<(int, string)> trainingsExcluded,
            int startIndex)
        {
            for (int index = startIndex; index < trainingsExcluded.Count; index++)
            {
                var nextTraining = trainingsExcluded[index];

                if (totalDuration + nextTraining.Item1 == duration)
                {
                    List<(int, string)> newResult = new List<(int, string)>(trainingsIncluded);
                    newResult.Add(nextTraining);

                    possiblePreLunchTrainingsForADay.Add(newResult);
                }
                else if (totalDuration + nextTraining.Item1 < duration)
                {
                    List<(int, string)> nextIncluded = new List<(int, string)>(trainingsIncluded);
                    nextIncluded.Add(nextTraining);
                    List<(int, string)> nextNotIncluded = new List<(int, string)>(trainingsExcluded);
                    nextNotIncluded.Remove(nextTraining);

                    GetPreLunchTrainings(duration, totalDuration + nextTraining.Item1,
                        nextIncluded, nextNotIncluded, startIndex++);
                }
            }
        }

        private static void SetTrackCalendar(List<(int, string)> trainings, int trackNmber)
        {
            List<(string, string, string)> newSchedule = new List<(string, string, string)>();
            List<string> preLunchScheds = new List<string>();
            double currentTime = TrackStartTime;

            // get all possible trainings from 9AM - 12Noon (180 minutes)
            var preLunchTrainings = GetAllPotentialTrainingsPreLunch(180, trainings);
            var isLunchFeasible = preLunchTrainings != null && preLunchTrainings.Count > 0;

            // check if a possible set of trainings could be scheduled before 12 Noon
            // And schedule those from a possible list
            if (isLunchFeasible)
            {
                preLunchTrainings.First().ForEach(t =>
                {
                    newSchedule.Add((DayTimeUtilities.ConvertToTime(currentTime), t.Item2, t.Item1.ToString() + "mins"));
                    currentTime += (t.Item1 / 60d);
                    preLunchScheds.Add(t.Item2);
                });

                // Schedule a lunch session at 12 Noon
                newSchedule.Add((DayTimeUtilities.ConvertToTime(currentTime), "Lunch", LunchDuration.ToString() + "mins"));
                currentTime += (LunchDuration / 60d);
            }

            // once pre-lunch trainings are added, add the rest
            trainings.Where(tr => !preLunchScheds.Contains(tr.Item2)).ToList().ForEach((x) =>
            {
                // if lunch was over-run, continue the session later
                if (currentTime < 12 && !isLunchFeasible && DayTimeUtilities.IsLunchOverRun(x.Item1, currentTime))
                {
                    var timeRemainingForLunch = DayTimeUtilities.GetTimeRemainingForLunch(currentTime);
                    var lunchOverRunBy = DayTimeUtilities.LunchOverRunBy(x.Item1, currentTime);

                    newSchedule.Add((DayTimeUtilities.ConvertToTime(currentTime), x.Item2, timeRemainingForLunch + "mins"));
                    currentTime += (timeRemainingForLunch/60d);

                    // Schedule a lunch session at 12 Noon
                    newSchedule.Add((DayTimeUtilities.ConvertToTime(currentTime), "Lunch", LunchDuration.ToString() + "mins"));
                    currentTime += (LunchDuration / 60d);

                    //continue the remaining session
                    newSchedule.Add((DayTimeUtilities.ConvertToTime(currentTime), x.Item2, lunchOverRunBy + "mins"));
                    currentTime += (lunchOverRunBy/60d);
                }
                else
                {
                    newSchedule.Add((DayTimeUtilities.ConvertToTime(currentTime), x.Item2, x.Item1.ToString() + "mins"));
                    currentTime += (x.Item1 / 60d);
                }
            });

            if (currentTime < 16)
            {
                // sharing session should only start after 4 PM
                currentTime = 16;
            }
            
            // Add sharing-session
            newSchedule.Add((DayTimeUtilities.ConvertToTime(currentTime), "Sharing Session", ""));

            printTrainingsForTrack(newSchedule, trackNmber);
        }

        private static void printTrainingsForTrack(List<(string, string, string)> trackSessions, int trackNumber)
        {
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("==== Track " + trackNumber + "====");

            for (int i = 0; i < trackSessions.Count; i++)
            {
                Console.WriteLine(trackSessions[i] + ",");
            }

            Console.WriteLine("-------------------------------------------------");
        }
    }
}
